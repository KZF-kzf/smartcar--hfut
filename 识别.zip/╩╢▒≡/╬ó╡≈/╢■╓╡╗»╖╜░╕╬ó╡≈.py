# Color Binary Filter Example
#
# This script shows off the binary image filter. You may pass binary any
# number of thresholds to segment the image by.

import sensor, image, time

sensor.reset()
sensor.set_framesize(sensor.QVGA)
sensor.set_pixformat(sensor.RGB565)
sensor.skip_frames(time = 2000)
clock = time.clock()

# Use the Tools -> Machine Vision -> Threshold Edtor to pick better thresholds.
red_threshold = (0,100,   0,127,   0,127) # L A B
green_threshold = (0,100,   -128,0,   0,127) # L A B
blue_threshold = (0,100,   -128,127,   -128,0) # L A B
my_threshold=(37, 82, -60, 51, 22, 106)
temp_threshold=(64, 100, -38, -7, 14, 127)
test_threshold=(29, 99, 1, -33, 1, 93)

detect_area = [54,41,217,139]
result_area = [122,83,83,35]

res_xy=[163,98]

while(True):
    # Test not green threshold
    for i in range(100):
        clock.tick()
        img = sensor.snapshot()
        img.binary([test_threshold])
        img.draw_rectangle(detect_area,color=(255,0,0))
        #img.draw_rectangle(result_area,color=(0,255,0))
        for r in img.find_rects(roi=detect_area,threshold = 50000):
            img.draw_rectangle(r.rect(), color = (255, 0, 0))
            for p in r.corners(): img.draw_circle(p[0], p[1], 5, color = (0, 255, 0))
            detect_roi = [r.x()-30,r.y()-30,r.w()+60,r.h()+60]
            img.draw_rectangle(detect_roi,color=(255,0,0))
            rect_xy = [r.x()+r.w()*0.5,r.y()+r.h()*0.5]
           # print((res[0]-rect_xy[0])*(res[0]-rect_xy[0])+
           #(res[1]-rect_xy[1])*(res[1]-rect_xy[1]))
            dx = rect_xy[0]-res_xy[0]
            dy = rect_xy[1]-res_xy[1]
            #dx < 0：车向左；dx > 0：车向右
            #dy < 0：车向上；dy > 0：车向下
            print("dx:",dx)
            print("dy:",dy)
