from machine import UART
import time
import pyb
from pyb import LED #导入LED

red = LED(1)    # 定义一个LED1   红灯
green = LED(2)  # 定义一个LED2   绿灯
blue = LED(3)   # 定义一个LED3   蓝灯
white = LED(4)  # 定义一个LED4   照明灯
white.on()



def A4Paper_Uart():
    res_c=[[0,0],[53,39],[91,26],[15,20],[34,70],[61,84],[81,61]]
    num = len(res_c)
    numl = []
    numl.append(num)
    uart.write(bytearray(numl))
    for i in range(num):
        uart.write(bytearray(res_c[i]))
        time.sleep(10)
    end = [98]
    uart.write(bytearray(end))
    white.on()
    time.sleep(500)
    white.off()





uart = UART(2, baudrate=115200)     # 初始化串口 波特率设置为115200 TX是B12 RX是B13


A4Paper_Uart()
time.sleep(1000)
green.on()

