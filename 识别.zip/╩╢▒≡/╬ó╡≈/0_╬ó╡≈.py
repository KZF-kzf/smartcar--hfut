# Find Rects Example
#
# This example shows off how to find rectangles in the image using the quad threshold
# detection code from our April Tags code. The quad threshold detection algorithm
# detects rectangles in an extremely robust way and is much better than Hough
# Transform based methods. For example, it can still detect rectangles even when lens
# distortion causes those rectangles to look bent. Rounded rectangles are no problem!
# (But, given this the code will also detect small radius circles too)...

import sensor, image, time

sensor.reset()
sensor.set_pixformat(sensor.RGB565) # grayscale is faster (160x120 max on OpenMV-M7)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 2000)
clock = time.clock()


#{"x":77, "y":105, "w":127, "h":86, "magnitude":157628}
#((77, 191), (204, 189), (183, 105), (118, 105))


large_roi = [63,85,186,139]

while(True):
    clock.tick()
    img = sensor.snapshot()

    # `threshold` below should be set to a high enough value to filter out noise
    # rectangles detected in the image which have low edge magnitudes. Rectangles
    # have larger edge magnitudes the larger and more contrasty they are...
    img.draw_rectangle(large_roi,color=(0,255,0))
    for r in img.find_rects(threshold = 20000,roi=large_roi):
        img.draw_rectangle(r.rect(), color = (255, 0, 0))
        if(r.h()==94):
            print("STOP")
        print(r)
        print(r.corners())
