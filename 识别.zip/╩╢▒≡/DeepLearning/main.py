# Untitled - By: KZF - 周六 3月 19 2022

import sensor, image, time
from machine import UART
import time
import pyb
from pyb import LED #导入LED
#(77, 100, 25, -8, -29, 57)
import math
import os, tf
import seekfree





def Circles_To_Location(rect_shape,circles):
    x_r=rect_shape[0]
    y_r=rect_shape[1]
    w_r=rect_shape[2]
    h_r=rect_shape[3]
    lenth = len(circles)

    X_rates=[]
    Y_rates=[]
    coordinates=[]
    for c in circles:
        x_c = c[0]
        y_c = c[1]
        x_rate = (x_c-x_r)/w_r
        y_rate = (h_r-(y_c - y_r))/h_r
        #X_rates.append(x_rate)
        #Y_rates.append(y_rate)
        coordinates.append([x_rate,y_rate])
    return coordinates       #(X_rates,Y_rates)


def deal(r,c):
    x_r = r[0]
    y_r = r[1]
    w_r = r[2]
    h_r = r[3]

    x_c = c[0]
    y_c = c[1]
    r_c = c[2]

    real_x_c = x_c - x_r
    real_y_c = y_c - y_r

    rate_x_c = real_x_c/w_r
    rate_y_c = real_y_c/h_r
    return (rate_x_c,rate_y_c)



def deals(r,c):
    lenth = len(c)
    for number in range(lenth):
        rate_x_c,rate_y_c = deal(r,c[number])
        print("-------------------")
        print("number: ",number+1)
        print("x比例：",rate_x_c)
        print("y比例：",rate_y_c)
        print("*******************")


def check(c,circle_roi):
    if(c.x()+c.r()>circle_roi[0]+circle_roi[2]):
        return 0
    if(c.x()-c.r()<circle_roi[0]):
        return 0
    if(c.y()+c.r()>circle_roi[1]+circle_roi[3]):
        return 0
    if(c.y()-c.r()>circle_roi[1]):
        return 0
    return 1

def A4Paper_detect(rect_roi,rect_threshold,Blob_thre):
    circles = []
    coordinates=[]
    flag_r=0
    flag_c=0

    #img = sensor.snapshot()
    img.draw_rectangle(rect_roi,color=[255,0,0])
    #lcd.show_image(img, 320, 240, zoom=2)
    for r in img.find_rects(threshold=rect_threshold,roi = rect_roi):
        whrate=0
        if(r.w()>r.h()):
            whrate=r.w()/r.h()
        else:
            whrate=r.h()/r.w()
        if(whrate<3):
            flag_r=1
            img.draw_rectangle(r.rect(),color=[255,0,0])
            #lcd.show_image(img, 320, 240, zoom=2)
          #  print(r.rect())
            #print([r.x()+5,r.y()+5,r.w()-10,r.h()-10])
            #print([r.x(),r.y(),r.w(),r.h()])
            #print("*******")
            #img.draw_rectangle([r.x()+10,r.y()+10,r.w()-20,r.h()-20],color=(0,0,0))
            for c in img.find_circles(threshold = 400, x_margin = 15, y_margin = 15, r_margin = 15,
            r_min = 1, r_max = 3, r_step = 1,roi=[r.x()+10,r.y()+10,r.w()-20,r.h()-20]):
                img.draw_circle(c.x(),c.y(),c.r(),color=[0,255,0])
                circles.append(c)
                flag_c=1
                #lcd.show_image(img, 320, 240, zoom=2)
           # img.draw_rectangle(r.rect(),color=[255,0,0])
            #img1=img.scale(x_scale=0.5,y_scale=0.5,copy=True,roi=[35,20,271,197])
            #lcd.show_image(img1, 320, 240, zoom=2)
        if(flag_r==1 and flag_c == 1):
            coordinates=Circles_To_Location(r.rect(),circles)
           # print(coordinates)
            for i in coordinates:
                i[0]=int(i[0]*100)
                i[1]=int(i[1]*100)
            return coordinates#这里返回的是[[x,y],[],[]......],且xy为两位整数
    return 0


#def A4Paper_detect(rect_roi,rect_threshold,Blob_thre):
    #circles = []
    #coordinates=[]
    #flag_r=0
    #flag_c=0
    #img.draw_rectangle(rect_roi,color=[255,0,0])
    ##lcd.show_image(img, 255, 200,40,20, zoom=2)
    #for r in img.find_rects(threshold=rect_threshold,roi = rect_roi):
        #whrate=0
        #if(r.w()>r.h()):
            #whrate=r.w()/r.h()
        #else:
            #whrate=r.h()/r.w()
        #if(whrate<3):
            #flag_r=1
            #img.draw_rectangle(r.rect(),color=[255,0,0])
          ##  print(r.rect())
            #for c in img.find_blobs([Blob_thre],roi=(r.x()+5,r.y()+5,r.w()-8,r.h()-8)):
                #print(c.pixels())
                #if(c.roundness()>0.4 and c.pixels()<60):
                    #img.draw_rectangle(c.rect(),color=[0,255,0])
                    #circles.append(c)
                    ##print(c.pixels())
                    #flag_c=1
                    ##print(c)
        ##lcd.show_image(img, 320, 240, zoom=2)
        #if(flag_r==1 and flag_c == 1):
            #coordinates=Circles_To_Location(r.rect(),circles)
           ## print(coordinates)
            #for i in coordinates:
                #i[0]=int(i[0]*100)
                #i[1]=int(i[1]*100)
            #return coordinates#这里返回的是[[x,y],[],[]......],且xy为两位整数
    #return 0



def A4Paper_Uart(coordinates):
    uart = UART(2, baudrate=115200)
    Result=[]
    #art串口用法很奇怪，必须这样发目标个数
    num = len(coordinates)
    numl=[]
    numl.append(num)
    uart.write(bytearray(numl))

    for i in coordinates:
        uart.write(bytearray(i))
        time.sleep(1)
    end = [101]
    uart.write(bytearray(end))

    return 1


class detectArray:
    def __init__(self):
        self.obj = []#种类 obj【i】保存的是字符串 种类的名字
        self.num = []#次数 0-5 num【i】表示 五次检查中第obj[i]类占的次数
        self.prob = []# 每次检测到的概率之和，作为num相等时的判别标准
        self.dnum=0
    def detectInsert(self,obj_class,obj_output,obj_location):
        flag = 1
        self.dnum+=1
        for i in range(len(self.obj)):
           # print(obj_class,self.obj[i],"这里是dInsert")
           # print("插入之前num",i,"值为",self.num[i])
            if(self.obj[i]==obj_class):
               self.num[i] = self.num[i] + 1
               #self.prob[i] = self.prob[i] + obj_output
              # print("插入之前num",i,"值为",self.num[i])
               flag = 0
               break
        if(flag):
            self.obj.append(obj_class)
            self.num.append(1)
            self.prob.append(obj_output)


    def getMax(self):#这里有一种特殊的情况，既num[i]==num[j],暂时不考虑
        maxid = 0
        for i in range(len(self.obj)):
            if self.num[i]>self.num[maxid]:#怎么会有这么愚蠢的错误
                maxid = i
        print("五次检测中，出现最多的为：",self.obj[maxid])
        temp=self.obj[maxid]
        #self.num=[]
        #self.obj=[]
        return temp

#Result = detectArray()
#返回0:detectnum≤5时，或者没有找到图片，会重复调用deeplearing函数

def DeepLearning(thre):
    for r in img.find_blobs([thre]):
        #我之前是想要从中选出最大面积 现在我直接滤掉小面积
        if(r.area()>3000):
            img1 = img.copy(r.rect())
            WhileTrue=0
            for obj in tf.classify(net , img1, min_scale=1.0, scale_mul=0.5,x_overlap=0.8, y_overlap=0.9):
                    #print("**********\nTop 1 Detections at [x=%d,y=%d,w=%d,h=%d]" % obj.rect())
                sorted_list = sorted(zip(labels, obj.output()), key = lambda x: x[1], reverse = True)

                obj_class = sorted_list[0][0]
                obj_output = sorted_list[0][1]
                obj_location = obj.rect()


                print(obj_class,obj_output,obj_location)
                #Result.detectInsert(obj_class,obj_output,obj_location)
                return [obj_class,obj_output,obj_location]
    #for r in img.find_rects(threshold=20000,roi=):
        #img1 = img.copy(r.rect())
        #WhileTrue=0
        #for obj in tf.classify(net , img1, min_scale=1.0, scale_mul=0.5,x_overlap=0.8, y_overlap=0.9):
                ##print("**********\nTop 1 Detections at [x=%d,y=%d,w=%d,h=%d]" % obj.rect())
            #sorted_list = sorted(zip(labels, obj.output()), key = lambda x: x[1], reverse = True)

            #obj_class = sorted_list[0][0]
            #obj_output = sorted_list[0][1]
            #obj_location = obj.rect()


            #print(obj_class,obj_output,obj_location)
            ##Result.detectInsert(obj_class,obj_output,obj_location)
            #return [obj_class,obj_output,obj_location]

def XY_Uart(xy_list):
    uart = UART(2, baudrate=115200)
    uart.write(bytearray(xy_list))
    #print(xy_list)
    time.sleep(10)
    green.on()







sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA) # we run out of memory if the resolution is much bigger...
#sensor.set_brightness(500)
sensor.skip_frames(time = 20)
sensor.set_auto_gain(False)  # must turn this off to prevent image washout...
sensor.set_auto_whitebal(False)  # must turn this off to prevent image washout...
clock = time.clock()




green = LED(2)
blue = LED(3)
white = LED(4)
thre=(65, 36, -45, 11, -29, 33)
Large_area=[49,29,239,175]

DP_roi=[39,24,237,165]

net_path = "mobilenet_v2_PCD.tflite"                                  # 定义模型的路径
labels = [line.rstrip() for line in open("/sd/labels.txt")]   # 加载标签
net = tf.load(net_path, load_to_fb=True)                                  # 加载模型

uart = UART(2, baudrate=115200)

lcd = seekfree.LCD180(2)
lcd.full()


while(True):
    clock.tick()
    img = sensor.snapshot()
    uart_num=0
    uart_num = uart.any()       # 获取当前串口数据数量
    coordinates=A4Paper_detect(rect_roi=Large_area,rect_threshold=30000,Blob_thre=thre)
    #if(coordinates):
        #print(coordinates)
   # lcd.show_image(img,320,240,zoom=2)
    img1=img.scale(x=0.25,y=0.25,copy=True)
    lcd.show_image(img1, 320, 240, zoom=2)
    #img1=img.scale(x_scale=0.25,y_scale=0.25,copy=True)
    #lcd.show_image(img1, 320, 240, zoom=2)
    if(uart_num):
        uart_str = uart.read(uart_num) # 读取串口数据
        if(uart_str):
            #print(len(coordinates))
            for i in range(1000):
                coordinates=A4Paper_detect(rect_roi=Large_area,rect_threshold=30000,Blob_thre=thre)
                if(coordinates):
                    if(len(coordinates)==12):
                        A4Paper_Uart(coordinates)
                        break
                    img = sensor.snapshot()
            white.on()
            time.sleep(500)
            white.off()
            break




white.on()
detect_num=0
Result = detectArray()
while(True):
    clock.tick()
    img = sensor.snapshot()
    uart_num=0
    uart_num = uart.any()       # 获取当前串口数据数量
    if(uart_num):
        uart_str = uart.read(uart_num) # 读取串口数据
        if(uart_str):
            green.on()
            detect_num=0
            Result = detectArray()
            #print("dnm0:",Result.dnum)
            print("dnm1:",Result.dnum)
            while(True):
                clock.tick()
                img = sensor.snapshot()
                ID=DeepLearning(thre)
                #print(ID)
                if(ID):
                    Result.detectInsert(ID[0],ID[1],ID[2])
                    detect_num+=1
                if(Result.dnum>=5):
                    resID = Result.getMax()
                    del Result
                   # print(Result)
                   # print("dnm3:",Result.dnum)
                   # print(resID)
                    lcd.show_image(img, 320, 240, zoom=2)
                    if(resID=="dog"):
                        lcd.show_str('dog',0, 44, lcd.RED, 1)
                        resID=1
                    elif(resID=="horse"):
                        lcd.show_str('horse',0, 44, lcd.RED, 1)
                        resID=2
                    elif(resID=="cat"):
                        lcd.show_str('cat',0, 44, lcd.RED, 1)
                        resID=3
                    elif(resID=="cow"):
                        lcd.show_str('cow',0, 44, lcd.RED, 1)
                        resID=4
                    elif(resID=="pig"):
                        lcd.show_str('pig',0, 44, lcd.RED, 1)
                        resID=5
                    elif(resID=="orange"):
                        lcd.show_str('orange',0, 44, lcd.RED, 1)
                        resID=6
                    elif(resID=="apple"):
                        lcd.show_str('apple',0, 44, lcd.RED, 1)
                        resID=7
                    elif(resID=="durian"):
                        lcd.show_str('durian',0, 44, lcd.RED, 1)
                        resID=8
                    elif(resID=="grape"):
                        lcd.show_str('grape',0, 44, lcd.RED, 1)
                        resID=9
                    elif(resID=="banana"):
                        lcd.show_str('banana',0, 44, lcd.RED, 1)
                        resID=10
                    elif(resID=="train"):
                        lcd.show_str('train',0, 44, lcd.RED, 1)
                        resID=11
                    elif(resID=="ship"):
                        lcd.show_str('ship',0, 44, lcd.RED, 1)
                        resID=12
                    elif(resID=="plane"):
                        lcd.show_str('plane',0, 44, lcd.RED, 1)
                        resID=13
                    elif(resID=="car"):
                        lcd.show_str('car',0, 44, lcd.RED, 1)
                        resID=14
                    elif(resID=="truck"):
                        lcd.show_str('truck',0, 44, lcd.RED, 1)
                        resID=15
                    temp=[]
                    temp.append(resID)
                    #print(resID)
                    uart.write(bytearray(temp))

                    break
        white.on()
        time.sleep(500)
        white.off()
    # uart.read会自动在数据末尾添加\n的操作，如果想去掉可以用strip()去掉
        # 例如 uart_str = uart.read(uart_num).strip()
        # 这样 uart_str得到的数据就不会被自动添加\n


#几点注意事项：
#1.看一下官方代码摄像头的那些配置 保持一致 不止dp，a4也是
#2.明天要做的事情有点多，优先 把流程跑通 即深度学习那套 然后是训练模型
#3.现在主要是数据发送的问题 还好
#4.有点担心驱动版
#5.关于a4纸垫高的问题 以及a4纸屏幕显示的问题 最好能把roi区域画出来 按理说是可以画的
#a4纸垫高多少量一下 然后用多大的板子 那个是否合适
#自动白平衡是否要关闭 参考一下seekfree代码
#6.我觉得还是找矩形函数用来detect比较好blob函数有些奇怪 明天用一下再说'
#7.把右手边这个小盒子带上 垫高应该差不多 a4纸查找用blob来做确实不稳定
#8.关于黄线
