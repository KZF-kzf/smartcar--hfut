# Find Rects Example
#
# This example shows off how to find rectangles in the image using the quad threshold
# detection code from our April Tags code. The quad threshold detection algorithm
# detects rectangles in an extremely robust way and is much better than Hough
# Transform based methods. For example, it can still detect rectangles even when lens
# distortion causes those rectangles to look bent. Rounded rectangles are no problem!
# (But, given this the code will also detect small radius circles too)...

import sensor, image, time
import pyb
from pyb import LED #导入LED

print('Start test LED\r\n') # 通过串口3输出提示信息 C8为TX C9为RX
red = LED(1)    # 定义一个LED1   红灯
green = LED(2)  # 定义一个LED2   绿灯
blue = LED(3)   # 定义一个LED3   蓝灯
white = LED(4)  # 定义一个LED4   照明灯
#white.on()

sensor.reset()
sensor.set_pixformat(sensor.RGB565) # grayscale is faster (160x120 max on OpenMV-M7)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 2000)
sensor.set_brightness(1500)
clock = time.clock()
rectroi = [21,0,287,156]
thre=(82, 56, -53, 10, -9, 5)





while(True):
    clock.tick()
    img = sensor.snapshot()
    #img.draw_rectangle(rectroi,color=[255,0,0])
    ## `threshold` below should be set to a high enough value to filter out noise
    ## rectangles detected in the image which have low edge magnitudes. Rectangles
    ## have larger edge magnitudes the larger and more contrasty they are...
    #for r in img.find_rects(roi=rectroi,threshold=1000):
        #img.draw_rectangle(r.rect(),color=[255,0,0])
        ##blackBlob = img.find_blobs([thre],roi=r.rect())
        #for i in img.find_blobs([thre],roi=r.rect()):
            #if((i.pixels()<60)):
                #img.draw_rectangle([i.x(),i.y(),i.w(),i.h()],color=[0,255,0])
    #for r in img.find_rects(threshold = 10000):
        #img.draw_rectangle(r.rect(), color = (255, 0, 0))
    #print(blackBlob)
        ##img.find_blobs()
    #img.binary([thre])
    #img.draw_rectangle(rectroi,color=[255,0,0])
    #for i in img.find_rects(roi=rectroi,threshold=200):
    img.draw_rectangle(rectroi,color=[0,255,0])
        #print(i)


    for i in img.find_blobs([thre],roi=rectroi):
        if(i.pixels()<80):
            img.draw_rectangle(i.rect(),color=[0,255,0])
            print(i)
