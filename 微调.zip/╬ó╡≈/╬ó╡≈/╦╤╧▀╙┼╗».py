# Find Lines Example
#
# This example shows off how to find lines in the image. For each line object
# found in the image a line object is returned which includes the line's rotation.

# Note: Line detection is done by using the Hough Transform:
# http://en.wikipedia.org/wiki/Hough_transform
# Please read about it above for more information on what `theta` and `rho` are.

# find_lines() finds infinite length lines. Use find_line_segments() to find non-infinite lines.

enable_lens_corr = False # turn on for straighter lines...

import sensor, image, time

sensor.reset()
sensor.set_pixformat(sensor.GRAYSCALE)
#sensor.set_pixformat(sensor.RGB565)# grayscale is faster
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 2000)
clock = time.clock()

# All line objects have a `theta()` method to get their rotation angle in degrees.
# You can filter lines based on their rotation angle.

min_degree = 0
max_degree = 179
test_far_threshold=(12, 100, -104, 108, -18, 95)


# All lines also have `x1()`, `y1()`, `x2()`, and `y2()` methods to get their end-points
# and a `line()` method to get all the above as one 4 value tuple for `draw_line()`.

large_roi = [49,41,226,164]
while(True):
    clock.tick()
    img = sensor.snapshot()
    #img.binary([test_far_threshold])
    #img.draw_rectangle(large_roi,color=(255,0,0   ))
    if enable_lens_corr: img.lens_corr(1.8) # for 2.8mm lens...

    # `threshold` controls how many lines in the image are found. Only lines with
    # edge difference magnitude sums greater than `threshold` are detected...

    # More about `threshold` - each pixel in the image contributes a magnitude value
    # to a line. The sum of all contributions is the magintude for that line. Then
    # when lines are merged their magnitudes are added togheter. Note that `threshold`
    # filters out lines with low magnitudes before merging. To see the magnitude of
    # un-merged lines set `theta_margin` and `rho_margin` to 0...

    # `theta_margin` and `rho_margin` control merging similar lines. If two lines
    # theta and rho value differences are less than the margins then they are merged.
    #img.draw_rectangle(large_roi,color=(0,0,0))
    for l in img.find_lines(threshold = 1000, theta_margin = 25, rho_margin = 25):
        if (min_degree <= l.theta()) and (l.theta() <= max_degree):
            img.draw_line(l.line(), color = (255, 255, 255))
            print(l.theta())

#l.theta()的理解：当俯视摄像头时，沿着摄像头纵向的直线，theta为0，且沿顺时针旋转逐渐增大，最大为180

#sita1=105
#sita2=38+90=128
#{"x1":231, "y1":107, "x2":179, "y2":172, "length":83, "magnitude":3059, "theta":39, "rho":247}
#{"x1":152, "y1":103, "x2":231, "y2":124, "length":82, "magnitude":1102, "theta":105, "rho":60}
#{"x1":78, "y1":125, "x2":145, "y2":172, "length":82, "magnitude":1527, "theta":125, "rho":58}
#{"x1":78, "y1":154, "x2":162, "y2":103, "length":98, "magnitude":1473, "theta":59, "rho":172}

# About negative rho values:
#
# A [theta+0:-rho] tuple is the same as [theta+180:+rho].
