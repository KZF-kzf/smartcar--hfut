# Color Binary Filter Example
#
# This script shows off the binary image filter. You may pass binary any
# number of thresholds to segment the image by.

import sensor, image, time
from machine import UART
import pyb
from pyb import LED #导入LED

print('Start test LED\r\n') # 通过串口3输出提示信息 C8为TX C9为RX
red = LED(1)    # 定义一个LED1   红灯
green = LED(2)  # 定义一个LED2   绿灯
blue = LED(3)   # 定义一个LED3   蓝灯
white = LED(4)  # 定义一个LED4   照明灯
sensor.reset()
sensor.set_framesize(sensor.QVGA)
sensor.set_pixformat(sensor.RGB565)
sensor.skip_frames(time = 2000)
clock = time.clock()


def XY_Uart(xy_list):
    uart.write(bytearray([-1]))
    print(bytearray([-1]))
    time.sleep(10)
    green.on()

uart = UART(2, baudrate=115200)

# Use the Tools -> Machine Vision -> Threshold Edtor to pick better thresholds.
red_threshold = (0,100,   0,127,   0,127) # L A B
green_threshold = (0,100,   -128,0,   0,127) # L A B
blue_threshold = (0,100,   -128,127,   -128,0) # L A B
my_threshold=(37, 82, -60, 51, 22, 106)
temp_threshold=(64, 100, -38, -7, 14, 127)
test_threshold=(29, 99, 1, -33, 1, 93)
detect_area = [54,41,225,203]
result_area = [122,83,83,35]
res_xy=[167.5,176]
#此时车中心到图片中心的距离为25cm
while(True):
    # Test not green threshold
    for i in range(100):
        clock.tick()
        img = sensor.snapshot()
        img.binary([test_threshold])
        img.draw_rectangle(detect_area,color=(255,0,0))
        #img.draw_rectangle(result_area,color=(0,255,0))
        Now_xy = []
        for r in img.find_rects(roi=detect_area,threshold = 50000):
            img.draw_rectangle(r.rect(), color = (255, 0, 0))
            for p in r.corners(): img.draw_circle(p[0], p[1], 5, color = (0, 255, 0))
            detect_roi = [r.x()-30,r.y()-30,r.w()+60,r.h()+60]
            img.draw_rectangle(detect_roi,color=(255,0,0))
            rect_xy = [r.x()+r.w()*0.5,r.y()+r.h()*0.5]
           # print((res[0]-rect_xy[0])*(res[0]-rect_xy[0])+
           #(res[1]-rect_xy[1])*(res[1]-rect_xy[1]))
            dx = rect_xy[0]-res_xy[0]
            dy = rect_xy[1]-res_xy[1]
            #dx < 0：车向左；dx > 0：车向右
            #dy < 0：车向上；dy > 0：车向下
            Now_xy.append(int(dx))
            Now_xy.append(int(dy))
            print("Now_xy:",Now_xy)
            XY_Uart(Now_xy)


