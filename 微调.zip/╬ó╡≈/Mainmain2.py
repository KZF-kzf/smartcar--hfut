# Untitled - By: KZF - 周六 3月 19 2022

import sensor, image, time
from machine import UART
import time
import pyb
from pyb import LED #导入LED
#(77, 100, 25, -8, -29, 57)
import math



#coordinates = [[13, 22], [11, 39], [12, 65], [12, 89],
               #[25, 77], [25, 35], [40, 58], [34, 89],
               #[52, 84], [57, 64], [49, 38], [49, 21],
               #[74, 28], [71, 49], [69, 83], [83, 87],
               #[80, 62], [83, 15], [92, 41], [89, 75]]


def getweishu(x):
    x_str = str(x)
    return len(x_str)


a = 25214903917
b = 11
m = math.pow(2, 10)


# f(x)=(ax + b) % m

def myRandom_son(x):
    f = a * x
    f = f + b
    f = f % m
    return f


def myRandom_Sequen(x, num):
    rans = []
    for i in range(num):
        x = myRandom_son(x)
        rans.append(x / m)
    return rans





def getdistmat(coordinates):
    num = len(coordinates)
    idx =0
    distmat2=[]
    for i in range(num):
        distmat2.append([0])
        for j in range(num-1):
            distmat2[i].append(0)
    for i in range(num):
        for j in range(num):
            distmat2[i][j] = math.sqrt(
            (coordinates[i][0] - coordinates[j][0])*(coordinates[i][0] - coordinates[j][0])+(coordinates[i][1] - coordinates[j][1])*(coordinates[i][1] - coordinates[j][1]))
    return distmat2


#TODO np.linalg.norm()转化

def initpara():
    alpha = 0.85
    t = (1, 100)
    markovlen = 500

    return alpha, t, markovlen


def IndexOut_Check(rans_idx,breed_idx,rans,breed):
    rans_idx += 1
    if (rans_idx >= 500):
        rans = myRandom_Sequen(breed[breed_idx], 100)
        breed_idx+=1
        if(breed_idx==500):
            breed_idx=0
        rans_idx = 0
    return rans_idx,breed_idx

#***************************************************************************************#

def fire(coordinates):

    coordinates.append([0,0])
    num = len(coordinates)


    #取整：
    for i in range(num):
        coordinates[i][0]=int(coordinates[i][0]*100)
        coordinates[i][1]=int(coordinates[i][1]*100)

   # print(coordinates)

    distmat = getdistmat(coordinates)  # 得到距离矩阵

    solutionnew =list(range(num))



    solutioncurrent = solutionnew.copy()
   # print(solutioncurrent)
    valuecurrent = 99000
    solutionbest = solutionnew.copy()
    valuebest = 99000  # np.max
    alpha, t2, markovlen = initpara()
    t = t2[1]
    rans = myRandom_Sequen(650, 600)
    breed=[1694, 1837, 1982, 787, 1083, 1316, 1734, 991, 1842, 1500, 1563, 787, 963, 1631, 1960, 1198, 807, 567, 501, 543, 1460, 724, 766, 948, 1560, 1942, 1005, 845, 711, 762, 1320, 1101, 937, 930, 1039, 1451, 617, 942, 1768, 1352, 1854, 1338, 1061, 750, 1194, 1978, 1847, 1808, 1775, 1641, 1729, 1741, 1176, 1183, 1566, 1291, 1386, 1699, 1457, 1560, 1687, 696, 1385, 1401, 1299, 1034, 610, 1514, 1317, 1241, 928, 1459, 1794, 1226, 1816, 1494, 1794, 739, 598, 926, 1107, 1881, 848, 632, 1819, 1033, 988, 1372, 656, 1842, 663, 1089, 1731, 898, 543, 1554, 1114, 1290, 860, 783, 1290, 805, 1323, 1523, 899, 522, 617, 839, 1026, 1813, 766, 1789, 1226, 1334, 1033, 1442, 1215, 1029, 1812, 1694, 1406, 1079, 1944, 1878, 1077, 1650, 517, 839, 600, 1147, 1592, 1754, 1008, 605, 769, 955, 1750, 567, 844, 1627, 614, 1280, 1651, 861, 1656, 1765, 1754, 699, 535, 619, 1457, 1837, 1157, 853, 1947, 1887, 1469, 870, 835, 1383, 1795, 1585, 1928, 1079, 869, 1485, 1842, 1459, 860, 1737, 972, 640, 1534, 1122, 721, 861, 1472, 1619, 1814, 1328, 1960, 1227, 1785, 777, 1182, 721, 810, 1777, 689, 1490, 1267, 1348, 1080, 1923, 794, 540, 529, 915, 1192, 1414, 824, 697, 1799, 1754, 1530, 1849, 1978, 1490, 1859, 1027, 1391, 519, 931, 1561, 1663, 1232, 1053, 1742, 947, 565, 1626, 974, 1700, 1592, 1443, 1284, 529, 596, 1179, 808, 1677, 856, 1222, 1677, 1434, 541, 1738, 1581, 1556, 662, 1527, 900, 785, 613, 1266, 1384, 943, 625, 809, 1206, 1094, 1971, 1261, 718, 1940, 829, 1470, 916, 550, 1540, 1681, 616, 1792, 1562, 1188, 561, 1936, 1314, 1282, 1094, 786, 1349, 1622, 1198, 552, 1078, 1356, 1113, 600, 1768, 1196, 1976, 1617, 1310, 1202, 1086, 1515, 726, 1563, 1233, 1231, 1547, 536, 1375, 1208, 797, 1095, 665, 1082, 1084, 1539, 1130, 795, 876, 1511, 1890, 863, 1878, 539, 825, 533, 1277, 864, 1098, 1766, 1059, 1589, 1309, 599, 1195, 569, 1334, 1784, 1114, 1184, 1119, 1303, 1320, 1950, 1408, 1914, 1432, 874, 509, 878, 1470, 803, 704, 808, 1969, 630, 1587, 1105, 1792, 1792, 1316, 801, 959, 1985, 1622, 910, 949, 686, 626, 1911, 1607, 1644, 1189, 1860, 1839, 723, 501, 1117, 681, 1678, 1741, 1950, 546, 1165, 1178, 844, 997, 1536, 1337, 1629, 1083, 1581, 712, 1094, 990, 1369, 827, 1460, 637, 1634, 693, 1225, 539, 1884, 1923, 921, 1079, 723, 1776, 1576, 1434, 1571, 1109, 1452, 1543, 1860, 1894, 1099, 1643, 1909, 879, 1848, 1418, 1516, 1082, 734, 1366, 625, 1971, 1731, 1223, 1137, 1410, 1898, 1386, 1614, 1476, 1182, 1914, 1303, 873, 639, 1172, 1424, 514, 1742, 1308, 1757, 1837, 1754, 1688, 1095, 1078, 1851, 1217, 954, 1092, 506, 1963, 1775, 1816, 1984, 1671, 1170, 1122, 540, 1408, 1053, 1438, 1755, 1722, 656, 907, 1038, 1664, 1564, 705, 1360, 1254, 1644, 1830, 1587, 1101, 1753, 1552, 1805, 1945, 833, 502, 883, 1854, 1830, 1846, 1239, 708, 980, 916, 898, 1495, 1546, 1945, 1610, 1036, 712, 1198, 775, 743, 1039, 563, 1255, 1519, 728, 1494, 1498, 1973]

    rans_idx = 0
    breed_idx = 0


    result = []  # 记录迭代过程中的最优解

    while t > t2[0]:
        for i in range(markovlen):

            rans_idx,breed_idx=IndexOut_Check(rans_idx,breed_idx,rans,breed)
            if rans[rans_idx] > 0.5:
                while True:

                    rans_idx,breed_idx=IndexOut_Check(rans_idx,breed_idx,rans,breed)
                    loc1 = int(math.ceil(rans[rans_idx] * (num - 1)))

                    rans_idx,breed_idx=IndexOut_Check(rans_idx,breed_idx,rans,breed)
                    loc2 = int(math.ceil(rans[rans_idx] * (num - 1)))

                    if loc1 != loc2:
                        break
                solutionnew[loc1], solutionnew[loc2] = solutionnew[loc2], solutionnew[loc1]
            else:  # 三交换
                while True:

                    rans_idx,breed_idx=IndexOut_Check(rans_idx,breed_idx,rans,breed)
                    loc1 = int(math.ceil(rans[rans_idx] * (num - 1)))

                    rans_idx,breed_idx=IndexOut_Check(rans_idx,breed_idx,rans,breed)
                    loc2 = int(math.ceil(rans[rans_idx] * (num - 1)))

                    rans_idx,breed_idx=IndexOut_Check(rans_idx,breed_idx,rans,breed)
                    loc3 = int(math.ceil(rans[rans_idx] * (num - 1)))

                    if ((loc1 != loc2) & (loc2 != loc3) & (loc1 != loc3)):
                        break
                if loc1 > loc2:
                    loc1, loc2 = loc2, loc1
                if loc2 > loc3:
                    loc2, loc3 = loc3, loc2
                if loc1 > loc2:
                    loc1, loc2 = loc2, loc1

                # 下面的三行代码将[loc1,loc2)区间的数据插入到loc3之后
                tmplist = solutionnew[loc1:loc2].copy()
                solutionnew[loc1:loc3 - loc2 + 1 + loc1] = solutionnew[loc2:loc3 + 1].copy()
                solutionnew[loc3 - loc2 + 1 + loc1:loc3 + 1] = tmplist.copy()
            valuenew = 0
            for i in range(num - 1):
                valuenew += distmat[solutionnew[i]][solutionnew[i + 1]]
            valuenew += distmat[solutionnew[0]][solutionnew[num-1]]
            # print (valuenew)

            if valuenew < valuecurrent:  # 接受该解
                # 更新solutioncurrent 和solutionbest
                valuecurrent = valuenew
                solutioncurrent = solutionnew.copy()
                if valuenew < valuebest:
                    valuebest = valuenew
                    solutionbest = solutionnew.copy()
            else:  # 按一定的概率接受该解
                rans_idx,breed_idx=IndexOut_Check(rans_idx,breed_idx,rans,breed)
                if rans[rans_idx] < math.exp(-(valuenew - valuecurrent) / t):
                    # np.random.rand()
                    valuecurrent = valuenew
                    solutioncurrent = solutionnew.copy()
                else:
                    solutionnew = solutioncurrent.copy()
        t = alpha * t
        result.append(valuebest)
        print(t)  # 程序运行时间较长，打印t来监视程序进展速度
    print(valuecurrent)
    print(num)
    print(solutionbest)
    for i in range(num):
        if(solutionbest[i]==num-1):
            solutionbest[0],solutionbest[i]= solutionbest[i],solutionbest[0]
    #print(solutionbest)
    return solutionbest








def Circles_To_Location(rect_shape,circles):
    x_r=rect_shape[0]
    y_r=rect_shape[1]
    w_r=rect_shape[2]
    h_r=rect_shape[3]
    lenth = len(circles)

    X_rates=[]
    Y_rates=[]
    coordinates=[]
    for c in circles:
        x_c = c[0]
        y_c = c[1]
        x_rate = (x_c-x_r)/w_r
        y_rate = (h_r-(y_c - y_r))/h_r
        #X_rates.append(x_rate)
        #Y_rates.append(y_rate)
        coordinates.append([x_rate,y_rate])
    return coordinates       #(X_rates,Y_rates)


def deal(r,c):
    x_r = r[0]
    y_r = r[1]
    w_r = r[2]
    h_r = r[3]

    x_c = c[0]
    y_c = c[1]
    r_c = c[2]

    real_x_c = x_c - x_r
    real_y_c = y_c - y_r

    rate_x_c = real_x_c/w_r
    rate_y_c = real_y_c/h_r
    return (rate_x_c,rate_y_c)



def deals(r,c):
    lenth = len(c)
    for number in range(lenth):
        rate_x_c,rate_y_c = deal(r,c[number])
        print("-------------------")
        print("number: ",number+1)
        print("x比例：",rate_x_c)
        print("y比例：",rate_y_c)
        print("*******************")


def check(c,circle_roi):
    if(c.x()+c.r()>circle_roi[0]+circle_roi[2]):
        return 0
    if(c.x()-c.r()<circle_roi[0]):
        return 0
    if(c.y()+c.r()>circle_roi[1]+circle_roi[3]):
        return 0
    if(c.y()-c.r()>circle_roi[1]):
        return 0
    return 1


Large_area=[37,12,236,155]
#Large_area=[48,39,207,135]
#Large_area=[20,13,279,180]
def A4Paper_detect():

    i=0
    flag_r = 0
    flag_c = 0
    rect1 = img.find_rects(threshold=7000,roi=Large_area)
    if(len(rect1)==1):
        rect2 = img.find_rects(threshold=4000,roi=rect1[0].rect())
        if(len(rect2)):
            img.draw_rectangle(rect2[0].rect(),color=(255,0,0))
            circle_roi = rect2[0].rect()
            flag_r=1;
            circles = img.find_circles(threshold = 1100, x_margin = 10, y_margin = 10, r_margin = 10,
            r_min = 2, r_max = 8, r_step = 2,roi=circle_roi)
            for c in circles:
                 img.draw_circle(c.x(), c.y(), c.r(), color = (255, 0, 0))
                 flag_c=1;
            if flag_c&flag_r:
                #deals(rect2[0].rect(),circles)
                coordinates=Circles_To_Location(rect2[0].rect(),circles)
                #print("X:",x)
                #print("Y:",y)
                #print("*********************")
                return coordinates
    return 0


def Draw_Line(c):
    num = len(c)
    for i in range(num-1):
        img.draw_line(c[i][0], c[i][1], c[i+1][0], c[i+1][1], color = (255,0,0), thickness = 2)
    time.sleep(1000)


def A4Paper_Uart(res_c,solution):
    uart = UART(2, baudrate=115200)
    real_res_c=[]
    num = len(res_c)
    numl=[]
    numl.append(num)
    uart.write(bytearray(numl))
    for i in solution:
        uart.write(bytearray(res_c[i]))
        real_res_c.append(res_c[i])
        time.sleep(10)
    end = [98]
    uart.write(bytearray(end))
    white.on()
    time.sleep(1000)
    white.off()
    return real_res_c



sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time = 2000)

red = LED(1)
green = LED(2)
blue = LED(3)
white = LED(4)
white.on()

while(True):
    img = sensor.snapshot()
    img.draw_rectangle(Large_area,color=[255,0,0])
    flag_c = 0
    res_c=[]
    coordinates=[]
    temp2 = []
    flag = 1
    while(True):
        img = sensor.snapshot()
        img.draw_rectangle(Large_area,color=[255,0,0])
        temp = A4Paper_detect()
        #print(flag_c)
        if(temp):
            if(flag == 1):
                temp2 = temp
                flag = 0
            if(len(temp)==len(temp2)):
                flag_c+=1
            else:
                flag_c =0
                temp2 = temp
        if(flag_c>=10):
            coordinates=temp
            break
    #因为要考虑从原点出发，所以在fire函数里做一些特殊处理
    white.on()
    #time.sleep(2000)
    #white.off()
    solution=fire(coordinates)
    print(solution)
    ##在Uart里将经过特殊处理fire函数返回的路径，变为原点为起点
    real=A4Paper_Uart(coordinates,solution)
    print(real)


