# Color Binary Filter Example
#
# This script shows off the binary image filter. You may pass binary any
# number of thresholds to segment the image by.

import sensor, image, time
from machine import UART
import pyb
from pyb import LED #导入LED


red = LED(1)    # 定义一个LED1   红灯
green = LED(2)  # 定义一个LED2   绿灯
blue = LED(3)   # 定义一个LED3   蓝灯
white = LED(4)  # 定义一个LED4   照明灯
white.on()
sensor.reset()
sensor.set_framesize(sensor.QVGA)
sensor.set_pixformat(sensor.RGB565)
sensor.skip_frames(time = 2000)
sensor.set_brightness(700)
clock = time.clock()
#white.on()
def XY_Uart(xy_list):
    uart.write(bytearray(xy_list))
    print(xy_list)
    time.sleep(1)
    green.on()

uart = UART(2, baudrate=115200)

# Use the Tools -> Machine Vision -> Threshold Edtor to pick better thresholds.
red_threshold = (0,100,   0,127,   0,127) # L A B
green_threshold = (0,100,   -128,0,   0,127) # L A B
blue_threshold = (0,100,   -128,127,   -128,0) # L A B
my_threshold=(37, 82, -60, 51, 22, 106)
temp_threshold=(64, 100, -38, -7, 14, 127)
test_threshold=(60, 80, 2, -38, 15, 127)
test_far_threshold=(75, 98, -53, -4, 20, 123)

detect_area = [0,65,319,175]
result_area = [122,83,83,35]
res_xy=[182,169]

def Mini_Adjust():
    #此时车中心到图片中心的距离为25cm
    while(True):
        # Test not green threshold
        #mybytes=uart.read(nbytes)
        #print(mybytes)
        #if(mybytes==0):
            #break
        clock.tick()
        img = sensor.snapshot()
        #img.binary([test_far_threshold])
       # img.draw_rectangle(detect_area,color=(255,0,0))
        #@img.draw_rectangle(result_area,color=(0,255,0))
        Now_xy = []
        Now_xy_temp=[]
        dx=0
        dy=0
        number = 0
        for i in range(3):
            #for i in img.find_blobs([test_far_threshold]):
                #img.draw_rectangle(i.rect(), color = (0, 255, 0))
            r=img.find_blobs([test_far_threshold])
            #for i in r:
                #print(i.convexity())
            i_S=[]
            Null=0
            Flag=0
            Result=[]
            w_h_rate=0

            for i in r:
                if(i.w()>i.h()):
                    w_h_rate=i.w()/i.h()
                else:
                    w_h_rate=i.h()/i.w()
                #if(i.area()>600):
                    #if(i.area()<4000 or w_h_rate<1.5):
                       ## print("whrate:",w_h_rate)
                        #if(i.area()<10000):
                            #if(i.density()<0.3):
                                ##print(i.density())
                                #if(i.elongation()<0.8):
                                    ##i_S.append(i.w()*i.h())、
                if(w_h_rate<1.7 and i.area()>400 and i.area()<10000):
                   # print(w_h_rate)
                    Result.append(i)
                   # print(i.area())
            #下面取出面积最大的一个，变量命名错误，不改了
            minium_idx = 0
            for i in range(len(Result)):
                Flag=1
                if(Result[i].area()>Result[minium_idx].area()):
                    minium_idx = i

            #下面取出距离最近的一个
            #myXY=[143,232]
            #for i in range(len(r)):
                #if((r[i].x(，)+r[i].y())<(r[minium_idx].x()+r[minium_idx].y())):
                    #minium_idx=i
            w_h_rate=0
            S=0
            if(Flag):

                img.draw_rectangle(Result[minium_idx].rect(), color = (0, 255, 0))


                #print(Result[minium_idx].elongation())
                #print(Result[minium_idx].density())
                #print(Result[minium_idx].area())
               # detect_roi = [Result[minium_idx].x()-30,Result[minium_idx].y()-30,Result[minium_idx].w()+60,Result[minium_idx].h()+60]
                #img.draw_rectangle(detect_roi,color=(255,0,0))
                rect_xy = [Result[minium_idx].x()+Result[minium_idx].w()*0.5,Result[minium_idx].y()+Result[minium_idx].h()*0.5]
               # print((res[0]-rect_xy[0])*(res[0]-rect_xy[0])+
               #(res[1]-rect_xy[1])*(res[1]-rect_xy[1]))
                dx_temp = rect_xy[0]-res_xy[0]
                dy_temp = rect_xy[1]-res_xy[1]
#                print("dx_temp dy_temp:",dx_temp,dy_temp)
                dx+=dx_temp
                dy+=dy_temp
                number = number + 1
                #dx < 0：车向左；dx > 0：车向右
                #dy < 0：车向上；dy > 0：车向下
                #break
        if(number):
            dx = dx/number
            dy = dy/number
        #print(number)
        if(dx>0):
            Now_xy.append(0)
        else:
            dx=-dx
            Now_xy.append(1)
        Now_xy.append(int(dx))
        if(dy>0):
            Now_xy.append(0)
        else:
            dy=-dy
            Now_xy.append(1)
        Now_xy.append(int(dy))
       # print("Now_xy:",Now_xy)
        XY_Uart(Now_xy)


nbytes = 1024
FLAG = 0
while(True):
    Mini_Adjust()

