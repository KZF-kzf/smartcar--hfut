# Color Binary Filter Example
#
# This script shows off the binary image filter. You may pass binary any
# number of thresholds to segment the image by.

import sensor, image, time,math
from machine import UART
import pyb
from pyb import LED #导入LED


red = LED(1)    # 定义一个LED1   红灯
green = LED(2)  # 定义一个LED2   绿灯
blue = LED(3)   # 定义一个LED3   蓝灯
white = LED(4)  # 定义一个LED4   照明灯‘
white.on()
sensor.reset()
sensor.set_framesize(sensor.QVGA)
sensor.set_pixformat(sensor.RGB565)
sensor.skip_frames(time = 2000)
#sensor.set_brightness(1200)
clock = time.clock()
#white.on()
def XY_Uart(xy_list):
    uart.write(bytearray(xy_list))
    print(xy_list)
    time.sleep(10)
    green.on()

uart = UART(2, baudrate=115200)

# Use the Tool s -> Machine Vision -> Threshold Edtor to pick better thresholds.
red_threshold = (0,100,   0,127,   0,127) # L A B
green_threshold = (0,100,   -128,0,   0,127) # L A B
blue_threshold = (0,100,   -128,127,   -128,0) # L A B
my_threshold=(37, 82, -60, 51, 22, 106)
temp_threshold=(64, 100, -38, -7, 14, 127)
test_threshold=(60, 80, 2, -38, 15, 127)
test_far_threshold=(69, 90, -50, -8, 46, 98)


detect_area = [0,65,319,175]
result_area = [122,83,83,35]
res_xy=[175,185]

def Mini_Adjust():
    #此时车中心到图片中心的距离为25cm
    while(True):
        # Test not green thresho ld
        #mybytes=uart.read(nbytes)
        #print(mybytes)
        #if(mybytes==0):
            #break
        clock.tick()
        img = sensor.snapshot()
        img.binary([test_far_threshold])
       # img.draw_rectangle(detect_area,color=(255,0,0))
        #img.draw_rectangle(result_area,color=(0,255,0))
        Now_xy = []
        Now_xy_temp=[]
        dx=0
        dy=0
        number = 0
        Lastx=[]
        Lasty=[]
        Nowx=[]
        Nowy=[]
        num_i=-1
        for i in range(4):
            r=img.find_rects(threshold = 50000)
            i_S=[]
            for i in r:
                i_S.append(i.w()*i.h())
            minium_idx = 0
            for i in range(len(i_S)):
                if(i_S[i]>i_S[minium_idx]):
                    minium_idx = i
            if(r):
                #img.draw_rectangle(r[0].rect(), color = (255, 0, 0))

                detect_roi = [r[minium_idx].x()-30,r[minium_idx].y()-30,r[minium_idx].w()+60,r[minium_idx].h()+60]
                #img.dra，吗w_rectangle(detect_roi,color=(255,0,0))
                rect_xy = [r[minium_idx].x()+r[minium_idx].w()*0.5,r[minium_idx].y()+r[minium_idx].h()*0.9]
               # print((res[0]-rect_xy[0])*(res[0]-rect_xy[0])+
               #(res[1]-rect_xy[1])*(res[1]-rect_xy[1]))
                dx_temp = rect_xy[0]-res_xy[0]
                dy_temp = rect_xy[1]-res_xy[1]

#                print("dx_temp dy_temp:",dx_temp,dy_temp)
                if(num_i==-1):
                    dx+=dx_temp
                    dy+=dy_temp
                    Nowx.append(dx)
                    Nowy.append(dy)
                    number = number + 1
                else:
                    #print(number)
                    fabx=math.fabs(Nowx[number-1]-dx_temp)
                    faby=math.fabs(Nowy[number-1]-dy_temp)
                    fabx_cmp=math.fabs(Nowx[number-1]/2)
                    faby_cmp=math.fabs(Nowy[number-1]/2)
                    #print(faby,faby_cmp)
                    if(dx_temp<Nowx[number-1] and dy_temp<Nowy[number-1]):
                        dx+=dx_temp
                        dy+=dy_temp
                        Nowx.append(dx)
                        Nowy.append(dy)
                        number = number + 1
                    elif fabx<fabx_cmp and faby<faby_cmp:
                        dx+=dx_temp
                        dy+=dy_temp
                        Nowx.append(dx)
                        Nowy.append(dy)
                        number = number + 1
            num_i = num_i+1
                #dx < 0：车向左；dx > 0：车向右
                #dy < 0：车向上；dy > 0：车向下
                #break
        if(number):
            dx = dx/number
            dy = dy/number
        #print(number)
        if(dx>0):
            Now_xy.append(0)
        else:
            dx=-dx
            Now_xy.append(1)
        Now_xy.append(int(dx))
        if(dy>0):
            Now_xy.append(0)
        else:
            dy=-dy
            Now_xy.append(1)
        Now_xy.append(int(dy))
       # print("Now_xy:",Now_xy)
        XY_Uart(Now_xy)


nbytes = 1024
FLAG = 0
while(True):
    Mini_Adjust()

