# Color Binary Filter Example
#
# This script shows off the binary image filter. You may pass binary any
# number of thresholds to segment the image by.

import sensor, image, time,math
from machine import UART
import pyb
from pyb import LED #导入LED


red = LED(1)    # 定义一个LED1   红灯
green = LED(2)  # 定义一个LED2   绿灯
blue = LED(3)   # 定义一个LED3   蓝灯
white = LED(4)  # 定义一个LED4   照明灯
sensor.reset()
sensor.set_framesize(sensor.QVGA)
sensor.set_pixformat(sensor.RGB565)
sensor.skip_frames(time = 2000)
#sensor.set_brightness(1200)
clock = time.clock()
#white.on()


def XY_Uart(xy_list):
    uart.write(bytearray(xy_list))
    print(xy_list)
    time.sleep(10)
    green.on()

uart = UART(2, baudrate=115200)

# Use the Tools -> Machine Vision -> Threshold Edtor to pick better thresholds.
red_threshold = (0,100,   0,127,   0,127) # L A B
green_threshold = (0,100,   -128,0,   0,127) # L A B
blue_threshold = (0,100,   -128,127,   -128,0) # L A B
my_threshold=(37, 82, -60, 51, 22, 106)
temp_threshold=(64, 100, -38, -7, 14, 127)
test_threshold=(60, 80, 2, -38, 15, 127)
#(40, 84, -27, 12, 90, 38)



detect_area = [0,65,319,175]
result_area = [122,83,83,35]
res_xy=[175,174]

def Mini_Adjust():
    #此时车中心到图片中心的距离为25cm
    while(True):
        # Test not green thresho ld
        #mybytes=uart.read(nbytes)
        #print(mybytes)
        #if(mybytes==0):
            #break
        clock.tick()
        img = sensor.snapshot()
        test_far_threshold=(68, 83, -33, -4, 22, 124)
        img.binary([test_far_threshold])
       # img.draw_rectangle(detect_area,color=(255,0,0))
        #img.draw_rectangle(result_area,color=(0,255,0))
        Now_xy = []
        Now_xy_temp=[]
        dx=0
        dy=0
        number = 0
        Lastx=[]
        Lasty=[]
        Nowx=[]
        Nowy=[]
        num_i=-1
        for i in range(4):
            r=img.find_rects(threshold = 50000)
            i_S=[]
            for i in r:
                i_S.append(i.w()*i.h())
            minium_idx = 0
            for i in range(len(i_S)):
                if(i_S[i]>i_S[minium_idx]):
                    minium_idx = i
            if(r):
                #img.draw_rectangle(r[0].rect(), color = (255, 0, 0))

                detect_roi = [r[minium_idx].x()-30,r[minium_idx].y()-30,r[minium_idx].w()+60,r[minium_idx].h()+60]
                #img.dra，吗w_rectangle(detect_roi,color=(255,0,0))
                rect_xy = [r[minium_idx].x()+r[minium_idx].w()*0.5,r[minium_idx].y()+r[minium_idx].h()*0.5]
               # print((res[0]-rect_xy[0])*(res[0]-rect_xy[0])+
               #(res[1]-rect_xy[1])*(res[1]-rect_xy[1]))
                dx_temp = rect_xy[0]-res_xy[0]
                dy_temp = rect_xy[1]-res_xy[1]

#                print("dx_temp dy_temp:",dx_temp,dy_temp)
                if(num_i==-1):
                    dx+=dx_temp
                    dy+=dy_temp
                    Nowx.append(dx)
                    Nowy.append(dy)
                    number = number + 1
                else:
                    #print(number)
                    fabx=math.fabs(Nowx[number-1]-dx_temp)
                    faby=math.fabs(Nowy[number-1]-dy_temp)
                    fabx_cmp=math.fabs(Nowx[number-1]/2)
                    faby_cmp=math.fabs(Nowy[number-1]/2)
                    #print(faby,faby_cmp)
                    if(dx_temp<Nowx[number-1] and dy_temp<Nowy[number-1]):
                        dx+=dx_temp
                        dy+=dy_temp
                        Nowx.append(dx)
                        Nowy.append(dy)
                        number = number + 1
                    elif fabx<fabx_cmp and faby<faby_cmp:
                        dx+=dx_temp
                        dy+=dy_temp
                        Nowx.append(dx)
                        Nowy.append(dy)
                        number = number + 1
            num_i = num_i+1
                #dx < 0：车向左；dx > 0：车向右
                #dy < 0：车向上；dy > 0：车向下
                #break
        if(number):
            dx = dx/number
            dy = dy/number
        else:
            return 1
        #print(number)
        if(dx>0):
            Now_xy.append(0)
        else:
            dx=-dx
            Now_xy.append(1)
        Now_xy.append(int(dx))
        if(dy>0):
            Now_xy.append(0)
        else:
            dy=-dy
            Now_xy.append(1)
        Now_xy.append(int(dy))
       # print("Now_xy:",Now_xy)
        XY_Uart(Now_xy)
        return 0


def Lines_Adjust():
    Failed_FindLine = 1
    #搜线
    #（未找到的话，或者确定找到的线都不能用，则直接return Failed_FindLine）
    #排除错误线
    #算解析式
    #求交点
    #求中心值
    #发送信息
    enable_lens_corr = False # turn on for straighter lines...


    sensor.reset()
    sensor.set_pixformat(sensor.GRAYSCALE)
    #sensor.set_pixformat(sensor.RGB565)# grayscale is faster
    sensor.set_framesize(sensor.QVGA)
    sensor.skip_frames(time = 2000)
    clock = time.clock()



    min_degree = 0
    max_degree = 179
    test_far_threshold=(12, 100, -104, 108, -18, 95)


    large_roi = [49,41,226,164]

    right_roi=[221,2,99,238]

    below_roi=[0,164,320,73]

    left_roi=[2,0,68,237]
    while(True):
        clock.tick()
        img = sensor.snapshot()
        Lines=[]
        if enable_lens_corr: img.lens_corr(1.8) # for 2.8mm lens...

        BELOW = 0
        below_line_PX=[]
        for l in img.find_lines(threshold = 1000, theta_margin = 25, rho_margin = 25,roi=below_roi):
            if (min_degree <= l.theta()) and (l.theta() <= max_degree):
                img.draw_line(l.line(), color = (255, 255, 255))
                BELOW=1
                if(l.theta()>=45 and l.theta()<=135):
                    below_line_PX.append(l)
                    dy=math.fabs((l.y1()+l.y2())/2-res_xy[1])
                    Now_xy=[3]
                    Now_xy.append(int(dy))
                    Failed_FindLine=0
                    XY_Uart(Now_xy)
                    print(Now_xy)
                    #这里是平行线
                #if(l.theta()<45 or l.theta()>135):
                    #这里是垂直线
                   # below_line_chuizhi.append(l)
                #print("itis bellow")
        #if(len(below_line_PX)):
            #Now_xy = []
            #Now_xy.append(3)
            #Now_xy.append(0)
            #Now_xy.append(0)
            #Now_xy.append(math.fabs(below_line_PX.y()))

        LeftFlag=0
        if(BELOW==0):
            left_line_CZ=[]
            for l in img.find_lines(threshold = 1000, theta_margin = 25, rho_margin = 25,roi=left_roi):
                if (min_degree <= l.theta()) and (l.theta() <= max_degree):
                    img.draw_line(l.line(), color = (255, 255, 255))
                    if(l.theta()<45 or l.theta()>135):
                         #这里是垂直线
                         left_line_CZ.append(l)
                         dx = math.fabs((l.x1()+l.x2())/2-res_xy[0])
                         LeftFlag=1

                         Now_xy=[4]
                         Now_xy.append(int(dx))
                         XY_Uart(Now_xy)
                         Failed_FindLine=0
                         print(Now_xy)
        if(BELOW==0 and LeftFlag==0):
            right_line_CZ=[]
            for l in img.find_lines(threshold = 1000, theta_margin = 25, rho_margin = 25,roi=right_roi):
                if (min_degree <= l.theta()) and (l.theta() <= max_degree):
                    img.draw_line(l.line(), color = (255, 255, 255))
                    if(l.theta()<45 or l.theta()>135):
                         #这里是垂直线
                         left_line_CZ.append(l)
                         dx = math.fabs((l.x1()+l.x2())/2-res_xy[0])

                         Now_xy=[5]
                         Now_xy.append(int(dx))
                         Failed_FindLine=0

                         XY_Uart(Now_xy)
                         print(Now_xy)
                    #print("itis right")
        sensor.reset()
        sensor.set_framesize(sensor.QVGA)
        sensor.set_pixformat(sensor.RGB565)
        sensor.skip_frames(time = 2000)
        #sensor.set_brightness(1200)
        clock = time.clock()
        break

        #接下来进行矫正
        #1.只有一个线 2.有两个线 3.有三个线

        #if(!len(Lines)):
            #return Failed_FindLine
        #else:
            #Failed_FindLine = 0

        ##第一步，筛选线
        ##逻辑：
        ##1.当找到三条符合条件线时，直接跳出
        ##2.当找到两条符合条件线时，暂存
        ##3.最后结果，如果是三条线，则直接算中心点
        ##如果是两条线，则判断是垂直线还是平行线进行粗调
        ##如果是一条线，算出线在摄像头缓冲区的左边还是右边，进行粗调
        ##如果最后的结果线集合里保存的是一条线，此时有两种情况
        ##   1.art只找到了一条可用线
        ##   2.art找到了多个线，但是只有一条可用线，其他线为干扰线
        ##   3.art只找到了一条干扰线（这里暂时先不考虑，后期可以让车子尝试左右看看或者向后移动）
        ##Line_num=0
        ##Line1.append(Lines[0])
        #SearchLineOverFlag = 0
        #ResultLine1=[]
        #ResultLine2=[]
        #for i in Lines:
            #Line1=[]#放置平行线
            #Line2=[]#放置垂直线
            #LineFlag1=1
            #LineFlag2=1
            #for j in Lines:
                #if(math.fabs(i.theta()-j.theta())<=5 and LineFlag1):
                    ##说明i与j平行
                    #Line1.append(i)
                    #Line1.append(j)
                    #LineFlag1=0
                #elif(math.fabs(i.theta()-j.theta())<=100 and
                #math.fabs(i.theta()-j.theta())>=80 and LineFlag2):
                    ##说明i与j垂直
                    #Line2.append(i)
                    #Line2.append(j)
                    #LineFlag2=0
                #if(len(Line1)+len(Line2)>=4):
                    #SearchLineOverFlag=1
                    #ResultLine1=Line1
                    #ResultLine2=Line2
                #elif(len(Line1)==2):
                    #ResultLine1=Line1
                #elif(len(Line1)==2):
                    #ResultLine2=Line2
                #if(SearchLineOverFlag):
                    #break
            #if(SearchLineOverFlag):
                #break
        #if(SearchLineFlag):
            ##说明找到了三条可用线
            ##TODO
            #find_CenterPoint()
        #elif(len(ResultLine1)==2):
            ##此时只找到了两条平行线
        #elif(len(ResultLine2)==2):
            ##此时只找到了两条垂直线
        #else:#此时art未找到成对的可用线
            ##从Line中选出可用线：原则：优先l.theta()<10 or l.theta()>170
            ##                      或者l.theta()<100 and l.theta()>80
            ##                       的直线
    return Failed_FindLine
nbytes = 1024
FLAG = 0
while(True):
    Failed_FindRect=Mini_Adjust()
    #if(Failed_FindRect):
        #Failed_FindLine=Lines_Adjust()
        #if(Failed_FindLine):
        ##发送错误信息
            #ERROR=[250,250]
            #XY_Uart(ERROR)


